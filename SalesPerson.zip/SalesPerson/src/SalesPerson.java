import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SalesPerson {
    private String name;
    private String title;
    private List<Double> sales;

    public SalesPerson(String name, String title) {
        this.name = name;
        this.title = title;
        this.sales = new ArrayList<>();
    }

    public void addSale(double sale) {
        sales.add(sale);
    }

    public Iterator<Double> iterSales() {
        return sales.iterator();
    }

    public String getName() {
        return name;
    }

    public String getTitle() {
        return title;
    }

    public double getTotalSales() {
        double total = 0;
        for (Double sale : sales) {
            total += sale;
        }
        return total;
    }

    public double getMinSales() {
        return sales.stream().min(Double::compareTo).orElse(0.0);
    }

    public double getMaxSales() {
        return sales.stream().max(Double::compareTo).orElse(0.0);
    }

    public double getAverageSales() {
        if (sales.isEmpty()) {
            return 0;
        }
        double sum = 0;
        for (Double sale : sales) {
            sum += sale;
        }
        return sum / sales.size();
    }
}
