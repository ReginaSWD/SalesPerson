import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class SalesTrackingApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<SalesPerson> salesPeople = new ArrayList<>();

        for (int i = 0; i < 3; i++) {
            System.out.print("Please enter sales person name: ");
            String name = scanner.nextLine();
            System.out.print("Please enter your sales person title: ");
            String title = scanner.nextLine();
            System.out.print("How many sales values will you enter for this sales person? ");
            int numSales = Integer.parseInt(scanner.nextLine());

            SalesPerson salesPerson = new SalesPerson(name, title);
            for (int j = 0; j < numSales; j++) {
                System.out.print("Please enter sales figure for " + name + ": ");
                double sale = Double.parseDouble(scanner.nextLine());
                salesPerson.addSale(sale);
            }
            salesPeople.add(salesPerson);
        }

        double companyTotalSales = 0;

        for (SalesPerson salesPerson : salesPeople) {
            System.out.println("\nSales person: " + salesPerson.getName());
            System.out.println("Total Sales: $" + String.format("%.2f", salesPerson.getTotalSales()));
            System.out.println("Min Sales: $" + String.format("%.2f", salesPerson.getMinSales()));
            System.out.println("Max Sales: $" + String.format("%.2f", salesPerson.getMaxSales()));
            System.out.println("Average Sales: $" + String.format("%.2f", salesPerson.getAverageSales()));
            System.out.println("----------------------------------------------------");
            companyTotalSales += salesPerson.getTotalSales();
        }

        System.out.println("Company total sales: $" + String.format("%.2f", companyTotalSales));
    }
}
